export function Footer() {
  return (
    <footer className="w-full bg-transparent mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-8 flex flex-wrap justify-between items-center">
        <div className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-8">
          <div>
            <h2 className="text-xl font-bold text-white">Arka Plan Kaldırıcı</h2>
            <p className="text-white/80 text-sm">Fotoğraflarınızdan kolayca arka planı kaldırın.</p>
          </div>
          <div className="flex space-x-4">
            <a href="/" className="text-white/80 hover:text-white">Ana Sayfa</a>
            <a href="/hakkimizda" className="text-white/80 hover:text-white">Hakkımızda</a>
            <a href="/iletisim" className="text-white/80 hover:text-white">İletişim</a>
          </div>
        </div>
        <div className="mt-4 md:mt-0">
          <p className="text-white/60 text-sm">© 2024 Arka Plan Kaldırıcı. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  )
}

