import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-white/10 backdrop-blur-sm border-t border-white/20">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-wrap justify-between">
          <div className="w-full md:w-1/4 mb-4 md:mb-0">
            <h2 className="text-lg font-semibold mb-2 text-white">Arka Plan Kaldırıcı</h2>
            <p className="text-sm text-white/80">Fotoğraflarınızdan kolayca arka planı kaldırın.</p>
          </div>
          <div className="w-full md:w-1/4 mb-4 md:mb-0">
            <h3 className="text-md font-semibold mb-2 text-white">Bağlantılar</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-white/80 hover:text-white transition-colors">Ana Sayfa</Link></li>
              <li><Link href="/about" className="text-white/80 hover:text-white transition-colors">Hakkımızda</Link></li>
              <li><Link href="/contact" className="text-white/80 hover:text-white transition-colors">İletişim</Link></li>
            </ul>
          </div>
          <div className="w-full md:w-1/4 mb-4 md:mb-0">
            <h3 className="text-md font-semibold mb-2 text-white">Yasal</h3>
            <ul className="space-y-2">
              <li><Link href="/privacy-policy" className="text-white/80 hover:text-white transition-colors">Gizlilik Politikası</Link></li>
              <li><Link href="/terms" className="text-white/80 hover:text-white transition-colors">Kullanım Şartları</Link></li>
            </ul>
          </div>
          <div className="w-full md:w-1/4">
            <h3 className="text-md font-semibold mb-2 text-white">İletişim</h3>
            <p className="text-sm text-white/80">E-posta: <a href="mailto:arkaplankaldir@gmail.com" className="hover:text-white transition-colors">arkaplankaldir@gmail.com</a></p>
          </div>
        </div>
        <div className="mt-8 text-center text-sm text-white/80">
          <p>&copy; {new Date().getFullYear()} Arka Plan Kaldırıcı. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  )
}

