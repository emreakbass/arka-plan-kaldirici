export function Footer() {
  return (
    <footer className="relative z-10 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 py-12">
          {/* About Section */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Arka Planı Kaldır</h3>
            <p className="text-white/70">
              Fotoğraflarınızdan kolayca arka planı kaldırın.
            </p>
          </div>

          {/* Links Section */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Bağlantılar</h3>
            <ul className="space-y-2">
              <li>
                <a href="/" className="text-white/70 hover:text-white transition-colors">
                  Ana Sayfa
                </a>
              </li>
              <li>
                <a href="/hakkimizda" className="text-white/70 hover:text-white transition-colors">
                  Hakkımızda
                </a>
              </li>
              <li>
                <a href="/iletisim" className="text-white/70 hover:text-white transition-colors">
                  İletişim
                </a>
              </li>
            </ul>
          </div>

          {/* Legal Section */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">Yasal</h3>
            <ul className="space-y-2">
              <li>
                <a href="/gizlilik-politikasi" className="text-white/70 hover:text-white transition-colors">
                  Gizlilik Politikası
                </a>
              </li>
              <li>
                <a href="/kullanim-sartlari" className="text-white/70 hover:text-white transition-colors">
                  Kullanım Şartları
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Section */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">İletişim</h3>
            <p className="text-white/70">
              E-posta: <a href="mailto:arkaplankaldir@gmail.com" className="hover:text-white transition-colors">arkaplankaldir@gmail.com</a>
            </p>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-white/10 py-6">
          <p className="text-center text-white/70">
            © 2024 Arka Planı Kaldır. Tüm hakları saklıdır.
          </p>
        </div>
      </div>
    </footer>
  )
}

