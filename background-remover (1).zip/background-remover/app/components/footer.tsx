import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-white/80 backdrop-blur-sm border-t">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-wrap justify-between">
          <div className="w-full md:w-1/4 mb-4 md:mb-0">
            <h2 className="text-lg font-semibold mb-2 bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text">Arka Plan Kaldırıcı</h2>
            <p className="text-sm text-gray-600">Fotoğraflarınızdan kolayca arka planı kaldırın.</p>
          </div>
          <div className="w-full md:w-1/4 mb-4 md:mb-0">
            <h3 className="text-md font-semibold mb-2 bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text">Bağlantılar</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text hover:opacity-80 transition-opacity">Ana Sayfa</Link></li>
              <li><Link href="/about" className="bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text hover:opacity-80 transition-opacity">Hakkımızda</Link></li>
              <li><Link href="/contact" className="bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text hover:opacity-80 transition-opacity">İletişim</Link></li>
            </ul>
          </div>
          <div className="w-full md:w-1/4 mb-4 md:mb-0">
            <h3 className="text-md font-semibold mb-2 bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text">Yasal</h3>
            <ul className="space-y-2">
              <li><Link href="/privacy-policy" className="bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text hover:opacity-80 transition-opacity">Gizlilik Politikası</Link></li>
              <li><Link href="/terms" className="bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text hover:opacity-80 transition-opacity">Kullanım Şartları</Link></li>
            </ul>
          </div>
          <div className="w-full md:w-1/4">
            <h3 className="text-md font-semibold mb-2 bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text">İletişim</h3>
            <p className="text-sm">E-posta: <a href="mailto:arkaplankaldir@gmail.com" className="bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text hover:opacity-80 transition-opacity">arkaplankaldir@gmail.com</a></p>
          </div>
        </div>
        <div className="mt-8 text-center text-sm">
          <p className="bg-gradient-to-r from-[#0051FF] via-[#0066FF] to-[#69B6FF] inline-block text-transparent bg-clip-text">&copy; {new Date().getFullYear()} Arka Plan Kaldırıcı. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  )
}

