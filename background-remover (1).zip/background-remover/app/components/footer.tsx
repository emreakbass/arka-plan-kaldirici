export function Footer() {
  return (
    <footer className="w-full bg-blue-600/20 backdrop-blur-sm mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <h2 className="text-xl font-bold text-white mb-4">Arka Plan Kaldırıcı</h2>
          <p className="text-white/80">Fotoğraflarınızdan kolayca arka planı kaldırın.</p>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Bağlantılar</h3>
          <ul className="space-y-2">
            <li><a href="/" className="text-white/80 hover:text-white">Ana Sayfa</a></li>
            <li><a href="/hakkimizda" className="text-white/80 hover:text-white">Hakkımızda</a></li>
            <li><a href="/iletisim" className="text-white/80 hover:text-white">İletişim</a></li>
          </ul>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Yasal</h3>
          <ul className="space-y-2">
            <li><a href="/gizlilik-politikasi" className="text-white/80 hover:text-white">Gizlilik Politikası</a></li>
            <li><a href="/kullanim-sartlari" className="text-white/80 hover:text-white">Kullanım Şartları</a></li>
          </ul>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-white mb-4">İletişim</h3>
          <p className="text-white/80">E-posta: arkaplankaldir@gmail.com</p>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <p className="text-center text-white/60">© 2024 Arka Plan Kaldırıcı. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  )
}

