'use client'

import { useState } from 'react'
import { removeBackground } from '../actions'

export default function BackgroundRemover() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const file = formData.get('file') as File

    if (!file) {
      setError('Lütfen bir dosya seçin')
      return
    }

    setIsProcessing(true)
    setError(null)
    setResult(null)

    try {
      const resultData = await removeBackground(formData)
      setResult(resultData)
    } catch (err) {
      console.error('Error:', err)
      setError(`Yükleme sırasında bir hata oluştu: ${err.message}`)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleDownload = () => {
    if (result) {
      const link = document.createElement('a')
      link.href = result
      link.download = 'removed-background.png'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
  }

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8">
        <h2 className="text-lg font-medium text-white mb-4">Resim Seçin</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="file"
              id="file"
              name="file"
              accept="image/*"
              onChange={() => {
                setError(null)
                setResult(null)
              }}
              className="w-full text-sm text-white/70
                         file:mr-4 file:py-2 file:px-4
                         file:rounded-full file:border-0
                         file:text-sm file:font-semibold
                         file:bg-white file:text-blue-700
                         hover:file:bg-white/90
                         cursor-pointer"
            />
          </div>
          {error && (
            <div className="text-red-300 text-sm">{error}</div>
          )}
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 
                     text-white rounded-lg font-medium
                     focus:outline-none focus:ring-2 focus:ring-blue-500 
                     focus:ring-offset-2 focus:ring-offset-blue-100
                     disabled:opacity-50 disabled:cursor-not-allowed
                     transition-colors duration-200"
          >
            {isProcessing ? 'İşleniyor...' : 'Arka Planı Kaldır'}
          </button>
        </form>
      </div>

      {result && (
        <div className="mt-8 bg-white/10 backdrop-blur-lg rounded-3xl p-8">
          <img 
            src={result} 
            alt="Arka planı kaldırılmış resim" 
            className="w-full rounded-lg shadow-lg" 
          />
          <button
            onClick={handleDownload}
            className="mt-4 w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 
                     text-white rounded-lg font-medium
                     focus:outline-none focus:ring-2 focus:ring-blue-500 
                     focus:ring-offset-2 focus:ring-offset-blue-100
                     transition-colors duration-200"
          >
            İndir
          </button>
        </div>
      )}
    </div>
  )
}

