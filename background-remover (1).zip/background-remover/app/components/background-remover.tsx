'use client'

import { useState } from 'react'
import { removeBackground } from '../actions'

export default function BackgroundRemover() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const file = formData.get('file') as File

    if (!file) {
      setError('Lütfen bir dosya seçin')
      return
    }

    console.log('File being uploaded:', file)

    setIsProcessing(true)
    setError(null)
    setResult(null)

    try {
      const resultData = await removeBackground(formData)
      setResult(resultData)
    } catch (err) {
      console.error('Error:', err)
      setError(`Yükleme sırasında bir hata oluştu: ${err.message}`)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleDownload = () => {
    if (result) {
      const link = document.createElement('a')
      link.href = result
      link.download = 'removed-background.png'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
  }

  return (
    <div className="w-full max-w-md">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="file" className="block text-sm font-medium text-gray-700">
            Resim Seçin
          </label>
          <input
            type="file"
            id="file"
            name="file"
            accept="image/*"
            onChange={(e) => {
              setError(null)
              setResult(null)
              console.log('Selected file:', e.target.files?.[0])
            }}
            className="mt-1 block w-full text-sm text-gray-500
                       file:mr-4 file:py-2 file:px-4
                       file:rounded-full file:border-0
                       file:text-sm file:font-semibold
                       file:bg-blue-50 file:text-blue-700
                       hover:file:bg-blue-100"
          />
        </div>
        {error && (
          <div className="text-red-500 text-sm mt-2">{error}</div>
        )}
        <button
          type="submit"
          disabled={isProcessing}
          className="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
        >
          {isProcessing ? 'İşleniyor...' : 'Arka Planı Kaldır'}
        </button>
      </form>

      {result && (
        <div className="mt-8">
          <h2 className="text-lg font-semibold mb-2">İşlenmiş Resim</h2>
          <img 
            src={result} 
            alt="Arka planı kaldırılmış resim" 
            className="max-w-full h-auto rounded-lg" 
          />
          <button
            onClick={handleDownload}
            className="mt-4 w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
          >
            İndir
          </button>
        </div>
      )}
    </div>
  )
}

