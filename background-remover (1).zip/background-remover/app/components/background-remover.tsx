'use client'

import { useState } from 'react'
import { removeBackground } from '../actions'

export default function BackgroundRemover() {
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<string | null>(null)
  const [fileName, setFileName] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const file = formData.get('file') as File

    if (!file) {
      setError('Lütfen bir dosya seçin')
      return
    }

    setIsProcessing(true)
    setError(null)
    setResult(null)

    try {
      const resultData = await removeBackground(formData)
      setResult(resultData)
    } catch (err) {
      console.error('Error:', err)
      setError(`Yükleme sırasında bir hata oluştu: ${err.message}`)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null)
    setResult(null)
    setFileName(e.target.files?.[0]?.name || null)
  }

  const handleDownload = () => {
    if (result) {
      const link = document.createElement('a')
      link.href = result
      link.download = 'removed-background.png'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
  }

  return (
    <div className="w-full max-w-xl mx-auto">
      <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8">
        <h2 className="text-lg font-medium text-white mb-4 text-center">Resim Seçin</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col items-center space-y-2">
            <label 
              htmlFor="file" 
              className="inline-flex px-4 py-2 bg-white text-blue-600 rounded-full 
                         hover:bg-blue-50 transition-colors duration-200 cursor-pointer"
            >
              Choose file
            </label>
            <span className="text-white/70 text-sm truncate max-w-full text-center">
              {fileName || 'No file chosen'}
            </span>
            <input
              type="file"
              id="file"
              name="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>
          {error && (
            <div className="text-red-300 text-sm mt-2 text-center">{error}</div>
          )}
          <button
            type="submit"
            disabled={isProcessing}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 
                     text-white rounded-lg font-medium
                     focus:outline-none focus:ring-2 focus:ring-blue-500 
                     focus:ring-offset-2 focus:ring-offset-blue-100
                     disabled:opacity-50 disabled:cursor-not-allowed
                     transition-colors duration-200"
          >
            {isProcessing ? 'İşleniyor...' : 'Arka Planı Kaldır'}
          </button>
        </form>
      </div>

      {result && (
        <div className="mt-8 bg-white/10 backdrop-blur-lg rounded-3xl p-8">
          <img 
            src={result} 
            alt="Arka planı kaldırılmış resim" 
            className="w-full rounded-lg shadow-lg" 
          />
          <button
            onClick={handleDownload}
            className="mt-4 w-full py-3 bg-blue-600 hover:bg-blue-700 
                     text-white rounded-lg font-medium
                     focus:outline-none focus:ring-2 focus:ring-blue-500 
                     focus:ring-offset-2 focus:ring-offset-blue-100
                     transition-colors duration-200"
          >
            İndir
          </button>
        </div>
      )}
    </div>
  )
}

