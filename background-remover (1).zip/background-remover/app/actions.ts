'use server'

export async function removeBackground(formData: FormData) {
  try {
    const file = formData.get('file') as File
    if (!file) {
      throw new Error('Dosya bulunamadı')
    }

    console.log('File size:', file.size, 'bytes')

    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    console.log('API Key length:', process.env.REMOVE_BG_API_KEY?.length || 0)

    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': process.env.REMOVE_BG_API_KEY || '',
      },
      body: buffer,
    })

    console.log('API Response status:', response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error('API Error:', errorText)
      throw new Error(`API isteği başarısız oldu: ${response.status} ${errorText}`)
    }

    const data = await response.arrayBuffer()
    const base64 = Buffer.from(data).toString('base64')
    return `data:image/png;base64,${base64}`
  } catch (error) {
    console.error('Detailed error:', error)
    throw new Error(`İşlem sırasında bir hata oluştu: ${error.message}`)
  }
}

