'use server'

export async function removeBackground(formData: FormData) {
  try {
    const file = formData.get('file') as File
    if (!file) {
      throw new Error('Dosya bulunamadı')
    }

    // Convert file to base64
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64Image = buffer.toString('base64')

    // Create form data with base64 image
    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': process.env.REMOVE_BG_API_KEY || '',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        image_file_b64: base64Image,
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('API Error:', errorText)
      throw new Error('API isteği başarısız oldu')
    }

    // Get the result as base64
    const result = await response.arrayBuffer()
    const resultBase64 = Buffer.from(result).toString('base64')
    
    return `data:image/png;base64,${resultBase64}`
  } catch (error) {
    console.error('Error:', error)
    throw new Error('İşlem sırasında bir hata oluştu')
  }
}

