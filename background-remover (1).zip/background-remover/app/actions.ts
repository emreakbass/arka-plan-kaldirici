'use server'

import { headers } from 'next/headers'

export async function removeBackground(formData: FormData) {
  const headersList = headers()
  console.log('Request headers:', Object.fromEntries(headersList))

  try {
    const file = formData.get('file') as File
    if (!file) {
      console.error("File not received in the form data.")
      throw new Error("Dosya yüklenemedi")
    }

    console.log('File name:', file.name)
    console.log('File size:', file.size, 'bytes')
    console.log('File type:', file.type)

    if (!process.env.REMOVE_BG_API_KEY) {
      console.error('REMOVE_BG_API_KEY is not set')
      throw new Error('API anahtarı bulunamadı')
    }

    const formDataForApi = new FormData()
    formDataForApi.append('image_file', file)

    console.log('Sending request to remove.bg API')
    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': process.env.REMOVE_BG_API_KEY,
      },
      body: formDataForApi,
    })

    console.log('API Response status:', response.status)

    if (!response.ok) {
      const errorDetails = await response.text()
      console.error('API Response Error:', errorDetails)
      throw new Error(`API isteği başarısız oldu: ${response.status} ${errorDetails}`)
    }

    const data = await response.arrayBuffer()
    const base64 = Buffer.from(data).toString('base64')
    return `data:image/png;base64,${base64}`
  } catch (error) {
    console.error('Detailed error:', error)
    throw new Error(`İşlem sırasında bir hata oluştu: ${error.message}`)
  }
}

