'use server'

export async function removeBackground(formData: FormData) {
  try {
    const file = formData.get('file') as File
    if (!file) {
      throw new Error('Dosya bulunamadı')
    }

    // Convert file to buffer
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    // Make the API request
    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': process.env.REMOVE_BG_API_KEY || '',
      },
      body: buffer,
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('API Error:', errorText)
      throw new Error('API isteği başarısız oldu')
    }

    // Convert the response to base64
    const data = await response.arrayBuffer()
    const base64 = Buffer.from(data).toString('base64')
    return `data:image/png;base64,${base64}`
  } catch (error) {
    console.error('Error:', error)
    throw new Error('İşlem sırasında bir hata oluştu')
  }
}

