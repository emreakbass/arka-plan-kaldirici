'use server'

import { writeFile } from 'fs/promises'
import { join } from 'path'

export async function removeBackground(formData: FormData) {
  try {
    const apiKey = process.env.REMOVE_BG_API_KEY || ''
    console.log('API Key length:', apiKey.length)

    const file = formData.get('file') as File
    if (!file) {
      throw new Error('No file provided')
    }

    console.log('File name:', file.name)
    console.log('File type:', file.type)
    console.log('File size:', file.size)

    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    const body = new FormData()
    body.append('image_file', new Blob([buffer], { type: file.type }), file.name)

    console.log('Sending request to remove.bg API...')

    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': apiKey,
      },
      body: body,
    })

    console.log('API Response status:', response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error('API Error response:', errorText)
      throw new Error(`API request failed: ${response.status} ${errorText}`)
    }

    const data = await response.arrayBuffer()
    const fileName = `bg-removed-${Date.now()}.png`
    const publicDir = join(process.cwd(), 'public')
    const filePath = join(publicDir, fileName)

    console.log('Writing file to:', filePath)

    await writeFile(filePath, Buffer.from(data))

    console.log('File successfully written')

    return `/api/images/${fileName}`
  } catch (error) {
    console.error('Detailed error:', error)
    throw new Error(`İşlem sırasında bir hata oluştu: ${error.message}`)
  }
}

