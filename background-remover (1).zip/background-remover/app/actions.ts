'use server'
 
import { writeFile } from 'fs/promises'
import { join } from 'path'
 
export async function removeBackground(formData: FormData) {
  try {
    const file = formData.get('file') as File
    if (!file) {
      throw new Error('Dosya bulunamadı')
    }

    // Convert the file to a Buffer
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    // Create a new FormData instance for the API
    const body = new FormData()
    const blob = new Blob([buffer], { type: file.type })
    body.append('image_file', blob, file.name)

    // Make the API request
    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': process.env.REMOVE_BG_API_KEY || '',
      },
      body: body,
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('API Error:', errorText)
      throw new Error('API request failed')
    }

    // Get the result
    const result = await response.arrayBuffer()
    const fileName = `bg-removed-${Date.now()}.png`
    const publicDir = join(process.cwd(), 'public')
    const filePath = join(publicDir, fileName)

    // Ensure the public directory exists
    try {
      await writeFile(filePath, Buffer.from(result))
    } catch (error) {
      console.error('File write error:', error)
      throw new Error('Failed to save the processed image')
    }

    return `/api/images/${fileName}`
  } catch (error) {
    console.error('Error in removeBackground:', error)
    throw new Error('İşlem sırasında bir hata oluştu')
  }
}

