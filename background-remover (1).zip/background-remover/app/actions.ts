'use server'

import { writeFile, mkdir } from 'fs/promises'
import { join } from 'path'

export async function removeBackground(formData: FormData) {
  console.log('API Key:', process.env.REMOVE_BG_API_KEY)
  try {
    const file = formData.get('file') as File
    if (!file) {
      throw new Error('Dosya bulunamadı')
    }

    const apiFormData = new FormData()
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const blob = new Blob([buffer])
    apiFormData.append('image_file', blob, file.name)

    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': process.env.REMOVE_BG_API_KEY || '',
      },
      body: apiFormData,
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('Remove.bg API Error:', errorText)
      throw new Error('API isteği başarısız oldu')
    }

    const data = await response.arrayBuffer()
    const fileName = `bg-removed-${Date.now()}.png`
    const publicDir = join(process.cwd(), 'public', 'processed-images')
    const filePath = join(publicDir, fileName)

    await mkdir(publicDir, { recursive: true })
    await writeFile(filePath, Buffer.from(data))

    return fileName
  } catch (error) {
    console.error('Error in removeBackground:', error)
    throw new Error('İşlem sırasında bir hata oluştu')
  }
}

