'use server'

import { writeFile } from 'fs/promises'
import { join } from 'path'
import crypto from 'crypto'

export async function removeBackground(formData: FormData) {
  try {
    const file = formData.get('file') as File
    if (!file) {
      throw new Error('Dosya bulunamadı')
    }

    // Create form data for the API
    const apiFormData = new FormData()
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const blob = new Blob([buffer])
    apiFormData.append('image_file', blob, file.name)

    // Make the API request
    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': process.env.REMOVE_BG_API_KEY || '',
      },
      body: apiFormData,
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('API Error:', errorText)
      throw new Error('API isteği başarısız oldu')
    }

    // Generate a unique filename
    const uniqueId = crypto.randomBytes(8).toString('hex')
    const fileName = `processed-${uniqueId}.png`

    // Save the file
    const data = await response.arrayBuffer()
    const filePath = join(process.cwd(), 'public', 'temp', fileName)
    await writeFile(filePath, Buffer.from(data))

    // Return the path to the saved file
    return `/temp/${fileName}`
  } catch (error) {
    console.error('Error:', error)
    throw new Error('İşlem sırasında bir hata oluştu')
  }
}

