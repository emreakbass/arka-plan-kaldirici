'use server'
 
import { writeFile } from 'fs/promises'
import { join } from 'path'

export async function removeBackground(formData: FormData) {
  try {
    // Log the API key (first few characters only for security)
    const apiKey = process.env.REMOVE_BG_API_KEY || ''
    console.log('API Key length:', apiKey.length)
    console.log('API Key preview:', apiKey.substring(0, 4) + '...')

    // Get and validate the file
    const file = formData.get('file') as File
    if (!file) {
      throw new Error('No file provided')
    }

    // Log file details
    console.log('File name:', file.name)
    console.log('File type:', file.type)
    console.log('File size:', file.size)

    // Convert file to buffer
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    // Create form data for API
    const body = new FormData()
    body.append('image_file', new Blob([buffer], { type: file.type }), file.name)

    // Log API request
    console.log('Sending request to remove.bg API...')

    // Make API request
    const response = await fetch('https://api.remove.bg/v1.0/removebg', {
      method: 'POST',
      headers: {
        'X-Api-Key': apiKey,
      },
      body: body,
    })

    // Log API response status
    console.log('API Response status:', response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.error('API Error response:', errorText)
      throw new Error(`API request failed: ${response.status} ${errorText}`)
    }

    // Get and process response
    const data = await response.arrayBuffer()
    const fileName = `bg-removed-${Date.now()}.png`
    const filePath = join(process.cwd(), 'public', fileName)

    // Log file writing
    console.log('Writing file to:', filePath)

    // Write the file
    await writeFile(filePath, Buffer.from(data))

    // Log success
    console.log('File successfully written')

    return `/api/images/${fileName}`
  } catch (error) {
    // Log detailed error
    console.error('Detailed error:', error)
    throw new Error(`İşlem sırasında bir hata oluştu: ${error.message}`)
  }
}

