import FileUpload from './components/file-upload'

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <div className="max-w-3xl w-full text-center space-y-8">
        <h1 className="text-4xl mb-8 text-white">
          <span className="font-extrabold">Arka Plan</span> Kaldırıcı
        </h1>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
          <FileUpload />
        </div>
      </div>
    </main>
  )
}

