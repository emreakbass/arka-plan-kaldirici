import BackgroundRemover from './components/background-remover'
import { AnimatedBackground } from './components/animated-background'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-blue-400 flex flex-col">
      <AnimatedBackground />
      <main className="flex-1 flex flex-col items-center justify-center p-4">
        <h1 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white to-white/80 tracking-tight mb-12">
          Arka Plan Kaldırıcı
        </h1>
        <BackgroundRemover />
      </main>
    </div>
  )
}

