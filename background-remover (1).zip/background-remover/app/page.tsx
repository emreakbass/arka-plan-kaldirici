import BackgroundRemover from './components/background-remover'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 flex flex-col items-center justify-center p-4">
      <main className="bg-white bg-opacity-10 backdrop-filter backdrop-blur-lg rounded-xl p-8 w-full max-w-md">
        <h1 className="text-4xl font-bold mb-8 text-center text-white">
          Arka Plan Kaldır
        </h1>
        <BackgroundRemover />
      </main>
    </div>
  )
}

