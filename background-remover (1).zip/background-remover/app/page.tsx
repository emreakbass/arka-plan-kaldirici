import BackgroundRemover from './components/background-remover'

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24 pb-32">
      <h1 className="text-4xl font-bold mb-8">Arka Plan Kaldırıcı</h1>
      <BackgroundRemover />
    </main>
  )
}

