import BackgroundRemover from './components/background-remover'

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24 pb-32">
      <div className="max-w-3xl w-full text-center space-y-8">
        <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-blue-800">
          Arka Plan Kaldırıcı
        </h1>
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg">
          <BackgroundRemover />
        </div>
      </div>
    </main>
  )
}

