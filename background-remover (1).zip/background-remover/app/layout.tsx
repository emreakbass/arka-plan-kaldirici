import './globals.css'
import type { Metadata } from 'next'
import { Plus_Jakarta_Sans } from 'next/font/google'
import { ThemeProvider } from './providers/theme-provider'
import { Footer } from './components/footer'
import { ThemeToggle } from './components/theme-toggle'

const plusJakartaSans = Plus_Jakarta_Sans({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Arka Plan Kaldırıcı',
  description: 'Fotoğraflarınızdan kolayca arka planı kaldırın',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tr" suppressHydrationWarning>
      <body className={`${plusJakartaSans.className} min-h-screen flex flex-col bg-gradient-to-br from-blue-600 to-blue-400`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <ThemeToggle />
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  )
}

