import './globals.css'
import type { Metadata } from 'next'
import { Plus_Jakarta_Sans } from 'next/font/google'

const plusJakartaSans = Plus_Jakarta_Sans({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Arka Plan Kaldırıcı',
  description: 'Fotoğraflarınızdan kolayca arka planı kaldırın',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tr">
      <body className={`${plusJakartaSans.className} min-h-screen`}>
        {children}
      </body>
    </html>
  )
}

